import DeadAirItemBase from "./item-base.mjs";

export default class DeadAirFeature extends DeadAirItemBase {}